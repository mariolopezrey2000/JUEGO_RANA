package com.mygdx.juego.utils;

import com.mygdx.juego.escenas.GameOverScreen;
import com.mygdx.juego.escenas.GameScreen;
import com.mygdx.juego.escenas.MainMenuScreen;



public class Pantallas {
    public static MainMenuScreen mainMenuScreen;
    public static GameScreen gameScreen;
    public static GameOverScreen gameOverScreen;
}
