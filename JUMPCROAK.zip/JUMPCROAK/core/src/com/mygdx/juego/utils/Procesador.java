package com.mygdx.juego.utils;

import com.badlogic.gdx.InputAdapter;

public abstract class Procesador extends InputAdapter {

}
