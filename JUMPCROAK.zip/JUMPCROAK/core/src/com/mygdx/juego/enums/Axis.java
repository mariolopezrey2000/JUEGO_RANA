package com.mygdx.juego.enums;

public enum Axis {
    X,
    Y
}
