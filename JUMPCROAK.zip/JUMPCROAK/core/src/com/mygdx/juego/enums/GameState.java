package com.mygdx.juego.enums;

public enum GameState {
    TO_START,
    RUNNING,
    OVER
}
